import React from "react";
import HomePage from "./pages/homepage/homepage.component";
import './App.css'
function App() {
  return (
    <div>
      <HomePage />
    </div>
  );
}

export default App;
